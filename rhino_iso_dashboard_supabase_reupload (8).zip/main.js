
const root = document.getElementById('root');

const supabase = supabase.createClient(
  'https://yabydepltoxxcxfssfqk.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlhYnlkZXBsdG94eGN4ZnNzZnFrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY5MjExMzAsImV4cCI6MjA3MjQ5NzEzMH0.gYSqFa9sLVfGcTglmrdckOK7_eSTvVjf4vZLXlglahI'
);

let loggedIn = false;

function renderLogin() {
  root.innerHTML = `
    <div class='min-h-screen flex items-center justify-center bg-gray-100'>
      <div class='w-full max-w-md p-6 bg-white rounded shadow'>
        <h2 class='text-xl font-bold mb-4 text-center'>Rhino Linings ISO 9001 Dashboard</h2>
        <input id='user' placeholder='Username' class='mb-2 w-full p-2 border rounded' />
        <input id='pass' type='password' placeholder='Password' class='mb-4 w-full p-2 border rounded' />
        <button onclick='login()' class='w-full bg-blue-500 text-white py-2 rounded'>Login</button>
      </div>
    </div>
  `;
}

async function renderDashboard() {
  const { data, error } = await supabase.storage.from('documents').list('');
  const fileList = (data || [])
    .map(file => `<li><a href="https://yabydepltoxxcxfssfqk.supabase.co/storage/v1/object/public/documents/${file.name}" target="_blank" class="text-blue-600 underline">${file.name}</a></li>`)
    .join('');

  root.innerHTML = `
    <div class='min-h-screen p-6 bg-white'>
      <h1 class='text-3xl font-bold mb-6 text-center'>Rhino Linings ISO 9001 Dashboard</h1>
      <div class='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4'>
        <div class='p-4 border rounded shadow'>
          <h2 class='text-lg font-semibold'>Information Bulletins</h2>
          <ul class='list-disc list-inside mt-2'>
            <li>Upcoming Internal Audit – Oct 2025</li>
            <li>Calibration Schedule Review – Due Sep 2025</li>
            <li>Training Records Update – Due Sep 15, 2025</li>
          </ul>
        </div>
        <div class='p-4 border rounded shadow'>
          <h2 class='text-lg font-semibold'>Document Upload</h2>
          <input type='file' id='uploadInput' class='block mb-2' />
          <button onclick='uploadFile()' class='bg-green-500 text-white px-4 py-2 rounded'>Upload</button>
        </div>
        <div class='p-4 border rounded shadow col-span-full'>
          <h2 class='text-lg font-semibold'>Document List</h2>
          <ul class='list-disc list-inside mt-2'>${fileList}</ul>
        </div>
      </div>
    </div>
  `;
}

async function uploadFile() {
  const file = document.getElementById('uploadInput').files[0];
  if (!file) return alert('No file selected');
  const { error } = await supabase.storage.from('documents').upload(file.name, file);
  if (error) return alert('Upload failed: ' + error.message);
  alert('File uploaded!');
  renderDashboard();
}

function login() {
  const user = document.getElementById('user').value;
  const pass = document.getElementById('pass').value;
  if (user === 'admin' && pass === 'admin') {
    loggedIn = true;
    renderDashboard();
  } else {
    alert('Invalid credentials');
  }
}

renderLogin();
